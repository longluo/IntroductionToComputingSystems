#include <stdio.h>

int main() 
{
   int echo;

   scanf("%d", &echo);
   printf("%d\n", echo);
}
