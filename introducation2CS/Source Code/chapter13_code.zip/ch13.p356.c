#include <stdio.h>

int main() 
{
   int x;
   int sum = 0;

   for (x = 0; x < 10; x++)
      sum = sum + x;
}
